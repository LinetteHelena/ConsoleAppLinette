﻿using ConsoleApp1;
using System;
using System.Collections.Generic;

namespace ConsoleAppForEach
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            List<string> nameList = new List<string>(new string[] { "Linette helena", "Birger", "Andreas", "Annemarie" });
             var name = new Model();
            foreach (var t in nameList)
            {
                var names = program.Names(t);
                name.FirstName = names.firstname; name.LastName = names.lastname;
                Console.WriteLine(name.FirstName + ' ' + name.LastName);
            }
        }


        public (string firstname, string lastname) Names(string name)
        {
            string firstName = string.Empty;
            string lastName = string.Empty;
            if (!String.IsNullOrEmpty(name))
            {
                var splitName = name.Split(new char[] { ' ' });
                if (splitName.Length > 1)
                {
                    lastName = splitName[splitName.Length - 1];
                }
                if (splitName.Length == 1)
                {
                    firstName = name;
                }
                else
                {
                    for (int i = 0; i < splitName.Length - 1; i++)
                    {
                        firstName += splitName[i].ToString() + " ";
                    }

                    firstName = firstName.Substring(0, firstName.Length - 1);
                }
            }
            return (firstName, lastName);
        }
    }
}
