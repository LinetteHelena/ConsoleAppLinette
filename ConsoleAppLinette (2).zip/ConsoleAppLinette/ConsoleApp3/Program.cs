﻿using Microsoft.Extensions.Caching.Memory;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Primitives;

namespace ConsoleApp3
{
    internal class Program
    {
        private static readonly IMemoryCache _memoryCache;
        private static readonly string _SWCache = "SWData";

        static async Task Main(string[] args)
        {
            Console.WriteLine("Type id and press enter to see information from SWAPI");
            var id = Console.ReadLine();

            var client = new RestClient("https://swapi.dev/api");
            var request = new RestRequest("/people/" + id, Method.Get);
            request.RequestFormat = DataFormat.Json;
            var response = await client.ExecuteAsync(request);

            if (response.IsSuccessful == false)
            {
                Console.WriteLine("There is none information on the given id");
            }
            else
            { 
                Console.WriteLine(response.Content);
            }
            Console.ReadLine();



        }

        static async void writecache(String id)
        {
            if (_memoryCache.Get(_SWCache) == null)
            {
                //var client = new RestClient("https://swapi.dev/api");
                //var request = new RestRequest("/people/" + id, Method.Get);
                //request.RequestFormat = DataFormat.Json;
                //response = await client.ExecuteAsync(request);

                //Dictionary<string, string> sWDict = new Dictionary<string, string>();
                //sWDict.Add(id, response.Content.ToString());

                //_memoryCache.Set<Dictionary<string, string>>(_SWCache, sWDict, DateTime.Now.AddHours(6));
            }

        }
    }

}
