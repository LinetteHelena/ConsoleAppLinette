﻿using System;
using System.Text.RegularExpressions;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numericValue;
            bool paliResult;
            Console.WriteLine("Type a string or an int to check whether it is a polindrome, and press Enter");
            var userInput = Console.ReadLine();
            Program program = new Program();
            bool isNumber = int.TryParse(userInput, out numericValue);
            if (isNumber != true)
                paliResult = program.Palindrome(userInput);
            else
                paliResult = program.Palindrome(numericValue);

            Console.WriteLine("User input: " + Regex.Replace(userInput, @"[^A-Za-z0-9]", "") + " Polindrome: " + paliResult);
        }

        public bool Palindrome(string name)
        {
            bool paliResult = false;
            name = Regex.Replace(name, @"[^A-Za-z0-9]", "");
            char[] name1 = name.ToCharArray();
            Array.Reverse(name1);
            
            if (name == new string(name1))
                paliResult = true;

            return paliResult;
        }

        public bool Palindrome(int number)
        {
            bool paliResult = false;
            char[] number1 = number.ToString().ToCharArray();
            Array.Reverse(number1);

            if (number == int.Parse(number1))
                paliResult = true;

            return paliResult;
        }

    }
}
