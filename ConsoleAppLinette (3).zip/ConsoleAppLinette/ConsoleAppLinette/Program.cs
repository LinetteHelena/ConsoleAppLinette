﻿using ConsoleApp1;
using System;
using System.Collections.Generic;

namespace ConsoleAppForEach
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            List<string> nameList = new List<string>(new string[] { "Linette helena", "Birger", "Andreas", "Annemarie" });

             List<Model> models = new List<Model>
            {
                new Model { FirstName = "navn", LastName = "navn1"},
                new Model { FirstName = "hej", LastName= "med dig"}
            };

            var name = new Model();
            foreach (var t in models)
            {
                Console.WriteLine(t.FirstName + ' ' + t.LastName);
            }
        }


  
    }
}
