﻿using System;
using System.Collections.Generic;

namespace ConsoleAppForEach
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> nameList = new List<string>(new string[] { "Linette", "Birger", "Andreas", "Annemarie" });

            foreach (var t in nameList)
                Console.WriteLine(t);
        }
    }
}
